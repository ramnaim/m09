const AUDIO_TO_PLAY = document.getElementById("mix");
var playvolume = 0.5;

function playAudio() {
    AUDIO_TO_PLAY.play();
}

function pauseAudio() {
    AUDIO_TO_PLAY.pause();
}

function mute() {
    playvolume = 0.0;
    setVolume();
}

function increaseVolume() {
    if (playvolume < 1.0){
        playvolume += 0.1;
    }
    setVolume();
}

function decreaseVolume() {
    if (playvolume > 0.0){
        playvolume -= 0.1;
    }
    setVolume();
}

function goBegin() {
    AUDIO_TO_PLAY.currentTime = 0;
}

function goEnd() {
    var audioDuration = AUDIO_TO_PLAY.duration;
    AUDIO_TO_PLAY.currentTime = audioDuration;
}

function setVolume() {
    AUDIO_TO_PLAY.volume = playvolume;
}
